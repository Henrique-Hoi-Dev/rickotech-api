export default {
  secret: '04484ed32b91e415adc9a6803842951e',
  expiresIn: '1d',
};
