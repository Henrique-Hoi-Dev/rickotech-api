import app from './app';

app.listen(3333);
console.log('Rodando na porta:3333');
